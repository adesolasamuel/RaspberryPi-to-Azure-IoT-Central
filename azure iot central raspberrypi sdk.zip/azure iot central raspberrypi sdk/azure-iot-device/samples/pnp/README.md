Edited by Adesola Samuel
Email: adesolasamuel2018@gmail.com

The original SDK is forked from Microsoft and can be gotten from this link: https://github.com/Azure/azure-iot-sdk-python

1. To send random message to Azure IoT Central, run randomiotcentral.py
2. To send data from a sensor (DHT11 in this case) to Azure IoT Central, run azuredht.py. Note that 
before your Raspberry pi should have been configured to be able to read from DHT before running this
code. Read this guide to set up your Raspberry pi for reading DHT: https://learn.adafruit.com/dht-humidity-sensing-on-raspberry-pi-with-gdocs-logging/python-setup
