# pip/PyPi aliases

These alias packages are used to occupy old package names for security reasons. They simply contain dependencies on the new package name.