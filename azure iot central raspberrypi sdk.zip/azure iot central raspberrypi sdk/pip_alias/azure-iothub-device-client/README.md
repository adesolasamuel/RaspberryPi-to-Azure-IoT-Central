# azure-iothub-device-client is now azure-iot-device

This package has been renamed. Use `pip install azure-iot-device` instead.

New package: [https://pypi.org/project/azure-iot-device/](https://pypi.org/project/azure-iot-device/)

The new package contains many breaking changes to APIs from the 1.x versions. Please see the [migration guide](https://github.com/Azure/azure-iot-sdk-python/blob/main/migration_guide.md) for details.

If you still need to use the old 1.x version APIs, the archival source code is still available [here](https://github.com/Azure/azure-iot-sdk-python/tree/v1-deprecated).

Note that 1.x is fully deprecated and no longer supported.
